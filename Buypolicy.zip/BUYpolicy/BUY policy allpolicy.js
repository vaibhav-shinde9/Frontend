import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';
import AfterLoginNavbar from './AfterLoginNavbar';
import Footer from './Footer';



function GetAllPolicy() {
 
    const [policies, setPolicies] = useState([]);

  
 
    useEffect(() => {
        axios.get("http://localhost:8080/healthinsurance/policy/all").then(resp => setPolicies(resp.data));
    },[])
 
    return (
      
        <div>
          <AfterLoginNavbar/>
            <h2 className='form-side'>All Policies</h2>
               {
                   policies.length > 0 ?
                    
               <table class="table table-bordered">
                 <thead class="thead-light">
                   <tr>
                     <th>Policy Id</th>
                     <th>Policy Name</th>
                     <th>Start Date</th>
                     <th>End Date</th>
                     <th>Term</th>
                     <th>Price</th>
                     <th>Created By</th>
                     <th>BuyPolicy</th>
                     {/* <th>RenewPolicy</th> */}
                   </tr>
                 </thead>
                 <tbody>
                 {policies.map(p =>
                   <tr>
                     <td>{p.policyId}</td>
                     <td>{p.policyName}</td>
                     <td>{p.startDate}</td>
                     <td>{p.endDate}</td>
                     <td>{p.startDate}</td>
                     <td>{p.price}</td>
                     <td>{p.createdBy}</td>
                
                      <td><Link to={`/policy/FetchPolicy/${p.policyId}`}>Buy</Link></td>
                     {/* <td><Link to={`/policy/Transaction/${p.transactionId}`}>Payment</Link></td> */}
                     {/* <td><Link to={`/policy/update/${p.transactionId}`}>Payment</Link></td> */}
                
                      
                    
                   </tr>
                    )}
                 </tbody>
               </table>
               : <h3><div class = "spinner-border"></div></h3>
                 }
            
                 <Footer/>
        </div>
    )
}
export default GetAllPolicy;