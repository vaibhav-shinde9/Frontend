import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import './UserDashboard.css';


function UserDashBoard(){
    return(
        <>
       <Navbar/>
       <div className='admin-container'>
        
        <img src='/img/User2.jpg' /> 

  
        </div>
        <Footer/>   



        </>






img {
    object-fit: cover;
    width: 100%;
    height: 100%;
    position:var(#0070ad);
    z-index: -1;
  }
  
  .admin-container {
    /* background: url('/images/img-home.jpg') center center/cover no-repeat; */
    height: 100vh;
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    box-shadow: inset 0 0 0 1000px rgba(0, 0, 0, 0.2);
    object-fit: contain;
  }
  
        
   
    )
}
export default UserDashBoard;