import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';
import Navbar from './components/Navbar';
import Transaction from './components/Transaction';
import GetAllPolicy from './components/GetAllPolicy';
import GetAllPolicyHolder from './components/GetAllPolicyHolder';
import FetchPolicy from './components/FetchPolicy';
import AfterLoginNavbar from './components/AfterLoginNavbar';
import UserDashBoard from './components/UserDashBoard';

function App() {
  return (
    <div className="App">
    <Router>
   <Routes>
   <Route path = '/UserDashboard' element = {<UserDashBoard/>}/> 
   <Route path = '/Navbar'element = {<Navbar/>}/>
   <Route path = '/policy/Transaction/:TransactionId' element={<Transaction/>}/>
   <Route path = '/policy/all' element={<GetAllPolicy/>}/>
   <Route path = '/policy/FetchPolicy/:policyId' element={<FetchPolicy/>}/>
   <Route path = '/policyholder/all' element={<GetAllPolicyHolder/>}/>
   <Route path = '/AfterLoginNavbar'element = {<AfterLoginNavbar/>}/> 

   </Routes>
 </Router>
     
    </div>
  );
}

export default App;
