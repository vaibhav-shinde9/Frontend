export const validationTransactionForm = (transaction) => {      
    let errors = {};
  
    if (!transaction.amount) {
        
        errors["amountErr"] = "Amount is required.";
    }
    
    if (!transaction.paymentDate) {
        
        errors["paymentDateErr"] = "PaymentDate  is required.";
    }
    return errors;
}
