import React, { useEffect, useState } from 'react';
import axios from 'axios';
import  './Transaction.css';
import AfterLoginNavbar from './AfterLoginNavbar';
import * as Validation from './Validation';
import { useNavigate } from 'react-router-dom';

function Transaction() {

    const [transaction, setTransactions] = useState({
        
        amount: '',
        paymentDate: '',

    });
    const [formErrors, setFormErrors] = useState({});
    const [istransactionSuccess, setIsTransactionSuccess] = useState('');
    const navigate = useNavigate();

    const handleChange = (event) => {
        setTransactions(transaction => ({ ...transaction, [event.target.name]: event.target.value }));
    }

    const handlesubmit = (event) => {
        event.preventDefault();
        const payload = {
            amount: transaction.amount,
            paymentDate: transaction.paymentDate

        }
        const validationErrors = Validation.validationTransactionForm(transaction);
        const noErrors = Object.keys(validationErrors).length === 0;
        setFormErrors(validationErrors);
        if (noErrors) {
        axios.post("http://localhost:8080/healthinsurance/transaction/create", payload).then(resp =>{
        
            if (resp.status === 200) {
                setIsTransactionSuccess("true");
                alert("Transaction Save with id: " + resp.data.transactionId)
                navigate('/UserDashBoard');
            }
        }).catch(error => {
            if (error.response.status === 401) {
                setIsTransactionSuccess("false");
            }
        })
    }
}


    return (

        <div className="Container">
         <AfterLoginNavbar></AfterLoginNavbar>
         {
                    istransactionSuccess === 'false' && <h4>Some Credential is wrong</h4>
                }
            
            <form className='Form'>
            <div>
                <h1 className='formHeader'>Make Payment</h1>
                <label className='form-group'>Enter Amount :</label>
                <input  type="text" name="amount" id="amount" placeholder='Enter Amount'  onChange={handleChange} value={transaction.amount}  /> 
                {
                                formErrors.amountErr && <div style={{ color: "red", paddingBottom: 10 }}>{formErrors.amountErr}</div>
                            }
            </div>
            <div>
                <label className='form-group'>Enter PaymentDate :</label>
                <input  type="date" name="paymentDate" id="paymentDate"   onChange={handleChange} value={transaction.paymentDate}  />
                {
                                formErrors.paymentDateErr && <div style={{ color: "red", paddingBottom: 10 }}>{formErrors.paymentDate}</div>
                            }
            </div>
            <div>
                <div >  
                    <button className='btn' onClick={handlesubmit}>Payment</button></div>
            </div>
            </form>

        </div>
        
    )
}

export default Transaction;
