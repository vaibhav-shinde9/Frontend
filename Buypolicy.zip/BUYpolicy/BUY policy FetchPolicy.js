import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom';
import AfterLoginNavbar from './AfterLoginNavbar';



function FetchPolicy() {
    const [policies,setpolicies] = useState(null);
    const {policyId} = useParams();

    useEffect(()=> {
        axios.get("http://localhost:8080/healthinsurance/policy/"+policyId).then(resp => setpolicies( resp.data));
    },[])
       
        return (
          
            <div className="container">
             <AfterLoginNavbar/>
           
                <h2>Policies Details</h2>
                {
                    policies !== null &&
                    <table class="table  table-bordered">
                        <thead class="thead-light">
                            <tr>
                            <th>Policy Id</th>
                            <th>Policy Name</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Term</th>
                            <th>Price</th>
                            <th>Created By</th>
                            <th>BuyPolicy</th>
                             
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>{policies.policyId} </td>
                                <td>{policies.policyName}</td>
                                <td>{policies.startDate}</td>
                                <td>{policies.endDate}</td>
                                <td>{policies.term}</td>
                                <td>{policies.price}</td>
                                <td>{policies.createdBy}</td>
                                <td><Link to={`/policy/Transaction/${policies.transactionId}`}>Payment</Link></td>
                                
                            </tr>
                        </tbody>
                    </table>
                }
          
            </div>
        )
    }

export default FetchPolicy;